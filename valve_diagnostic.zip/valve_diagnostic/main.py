import pandas as pd
import glob
import os
import csv


START_ROW = 33
START_COL = 3

path = f"{os.getcwd()}/data/ftp_in"
csv_files = glob.glob(os.path.join(path,"*.csv"))


for f in csv_files:
    with open(f) as file:
        reader = csv.reader(file)
        rows = list (reader)
        print(type(rows))
    
    f_w = str.replace(f,"ftp_in","archieve")
    print(f_w) 
    with open(f_w,"w") as file:
        file.write(rows)