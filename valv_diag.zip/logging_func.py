import pandas as pd
import datetime as dt

def log_create(log_content:str, log_file:str):
    try:
        log_file_df = pd.read_csv(log_file)
    except FileNotFoundError:
        log_file_df = pd.DataFrame(
            {
                "Timestamp": dt.datetime.now(),
                "File Name": log_content
        }, index=[1]
        )
        log_file_df.to_csv(log_file,index=False)
    else:
        new_log = pd.DataFrame({
            "Timestamp": dt.datetime.now(),
            "File Name": log_content
        }, index = [len(log_file_df)+1]
        )
        log_file_df = pd.concat([log_file_df,new_log], ignore_index = True)
        log_file_df.to_csv(log_file, index=False)
