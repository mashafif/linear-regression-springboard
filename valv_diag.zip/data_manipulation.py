import pandas as pd
import numpy as np

def digital_data_conv(data,ON_exp):
    for col in data.iloc[:,3:]:
        print(f"iterated column:{col}")
        if data[col].dtype == object:
            print(f"processed column:{col}")
            data[col]=np.where(data[col]==ON_exp,1,0)
            data[col]=data[col].astype(float)
    return data

