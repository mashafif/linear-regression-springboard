import pandas as pd
import glob
import os
import csv
import datetime as dt
import numpy as np
import csv_preprocessing as csv_p
import logging_func as log_f
import data_manipulation as d_mp

CSV_PROPERTY_NO = 6
EMPTY_ROW = 2
EMPTY_COL = 1
UNUSED_HEADER = 2





    
csv_p.csv_init()

path = f"{os.getcwd()}/data/ftp_in"
csv_files = glob.glob(os.path.join(path,"*.csv"))
print(csv_files)

for f in csv_files:
    print(f)
    historical_df = csv_p.csv_import_to_df(csv_file=f)
    print(historical_df.dtypes)
    historical_df = d_mp.digital_data_conv(historical_df, "ON")
    f_w = str.replace(f,"ftp_in","archieve")
    f_w = str.replace(f_w, ".csv","_ARCHIEVE.csv")

    historical_df.to_csv(f_w,index=False)
    
    #f_arch = str.replace(f_w,".csv","_ARCH.csv")
    os.remove(f)
    processed_file = str.replace(f, f"{path}\\","")
    print(processed_file)
    log_f.log_create(log_content=processed_file, log_file="file_process_log.csv")
    new_df= csv_p.convert_time(historical_df)
                
    

