import pandas as pd
import numpy as np

def digital_data_conv(data,ON_exp):
    for col in data:
        if data[col].dtype == object:
            data[col]=np.where(data[col]==ON_exp,1,0)
            data[col]=data[col].astype(float)
        return data

