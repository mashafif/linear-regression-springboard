import pandas as pd
import glob
import os
import csv
import datetime as dt
import numpy as np

ARCHIEVE_DIR="/data/archieve"
FTP_IN_DIR = "/data/ftp_in"
ARCHIEVE_SUFFIX = "_T_ARCH.csv"
FTP_SUFFIX = "_T.csv"
FILE_INDEX_POS = -12

CSV_PROPERTY_NO = 6
EMPTY_ROW = 2
EMPTY_COL = 1
UNUSED_HEADER = 2

#This function is only for testing will be deleted later
def csv_init(archieve_dir:str = ARCHIEVE_DIR, ftp_in_dir:str = FTP_IN_DIR,
             archieve_sufix:str = ARCHIEVE_SUFFIX, ftp_suffix:str = FTP_SUFFIX,
             file_index_pos:int = FILE_INDEX_POS ):
    try:
        path_try = f"{os.getcwd()}{archieve_dir}"
        csv_files_old = glob.glob(os.path.join(path_try,f"*{archieve_sufix}"))
        print(path_try)
        print(csv_files_old)
    except FileNotFoundError:
        pass
    else:
        for f in csv_files_old:
            archieve_index = int(f"{f[file_index_pos-2]}{f[file_index_pos-1]}{f[file_index_pos]}")
            print(archieve_index)
            f_old = str.replace(f,f"{archieve_index}{archieve_sufix}",f"{archieve_index+1}{ftp_suffix}")
            f_old = str.replace(f_old,archieve_dir, ftp_in_dir)
            print(f"f old : {f_old}")
            os.rename(f,f_old)


#Function to convert the m-system raw csv files to standard csv format
def csv_import_to_df(csv_file,
                     csv_property_no:int = CSV_PROPERTY_NO, empty_row:int = EMPTY_ROW,
                     empty_col = EMPTY_COL, unused_header=UNUSED_HEADER):
    
    #Open raw csv files recieved from m-system and import as list
    with open(csv_file) as file:
        reader = csv.reader(file)
        rows = list (reader)
        #print(rows)
    
    #Determine the starting coulumn and row based on the no. of parameters/pens , blank row, etc.
    no_of_params = int(rows[3][1])
    start_rows = no_of_params+ csv_property_no + unused_header + empty_row

    #Extract only the timeseries data from the raw csv data list
    historical = [row[empty_col::] for row in rows[start_rows::]]

    #add column name to date, time, and miliseconds
    historical[0][0] = "DATE"
    historical[0][1] = "HOUR_MIN_SEC"
    historical[0][2] = "MILISECONDS"
    
    #Change the list to data frame
    historical_df = pd.DataFrame(historical[1::],columns=historical[0])

    #Perform Data Type conversion
    ms_col = ["MILISECONDS"]
    time_col = [col for col in historical[0][:2:]]
    digital_col = [col for col in historical[0] 
                if historical_df[col].str.contains("OFF").any() 
                or historical_df[col].str.contains("ON").any()]
    string_col = time_col + digital_col
    data_col = [col for col in historical[0] if col not in string_col and col not in ms_col]

    historical_df[ms_col] = historical_df[ms_col].astype(int)
    historical_df[string_col] = historical_df[string_col].astype(str)
    historical_df[data_col] = historical_df[data_col].astype(float)

    #Return the converted time series dataframe
    return historical_df
    

