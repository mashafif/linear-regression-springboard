import pandas as pd
import glob
import os
import csv
import datetime as dt
import numpy as np
import csv_preprocessing as csv_p
import logging_func as log_f
import requests
from Habanerots_API_signal_mod import *

# CSV_PROPERTY_NO = 6
# EMPTY_ROW = 2
# EMPTY_COL = 1
# UNUSED_HEADER = 2
API_ENDPOINT = "https://www.tirp2.axnavi.com/historian/api"
PROXIES =  {'https': 'http://proxy.toshiba.co.jp:8080'}
SITE_NAME = "VLV_TEST_SITE_1"
DEVICE_ID = "Z3Q2XB4HTD5J32EAPMM499QXM4"

TOKEN = "eyJhbGciOiJFZERTQSIsImtpZCI6IjVwNTYxNUVwZHMwb3JvSm01S2JEVFItNVFMNWJsUzlOR1MweU05emprTG8iLCJ0eXAiOiJKV1QifQ.eyJjbGllbnRfaWQiOiJOcUxsa1pNTlQxRlJLdlU1WHpialJoIiwiZXhwIjoxNjkwNjAzMzk3LCJpYXQiOjE2OTA1MTY5OTcsImlzcyI6Imh0dHBzOi8vaWRwLmhhYmFuZXJvdHMtY29tbW9uLnRpcnAyLmF4bmF2aS5jb20vcmVhbG1zLzQiLCJzY29wZSI6ImVtYWlsIG9wZW5pZCBwcm9maWxlIiwic3ViIjoiODYxNjQyMzY4MDI0MDU3NDMzIn0.0DscEL3mRn2ZdxF5H1GS4oQ1Uwo18Q0Fcs6NCxzNTKM0vsy6WVLCp_gl5-0SapvApJMHii6Vtaj_LIAha2pmBA"




modify_signal_json=        {
            "tsSignalId": "CV_POS",
            "tsDeviceId": DEVICE_ID,
            "tsDescription": "CV POSITION",
            "tsHHAlarm": None,
            "tsHAlarm": None,
            "tsLAlarm": None,
            "tsLLAlarm": None,
            "tsDiffAlarmLimit": None
            
        }


path = f"{os.getcwd()}/data/ftp_in"
csv_files = glob.glob(os.path.join(path,"*.csv"))

historical_df = csv_p.csv_import_to_df(csv_file=csv_files[0])

column_list = list(historical_df.columns)[3::]
print(column_list)


character_replacement={
    "POS" : "POSITION",
    "_": " ",
    "TURB":  "TURBINE",
    "START": "START STATUS",
    "STOP" : "STOP STATUS",
    "LO" : "LOW",
    "SRV": "SERVO",
    "L" : "LOW",
    "VLV": "VALVE",
    "PRES": "PRESSURE"
}

for signal_ID in column_list:
    signal_description = signal_ID
    for key in character_replacement:
        signal_description=str.replace(signal_description, key, character_replacement[key])
    signal_ID_split = str.split(signal_ID,"_")
    signal_json = {
        "signals":[
            {
            "tsSignalId": signal_ID,
            "tsClassType": "SensorPoint",
            "tsDeviceId": DEVICE_ID,
            "tsDescription": signal_description,
            "tsUnit": "count",
            "tsDecimalPlaces": 2,
            "tsDatatype": "float",
            "tsAlarmStatus": "Normal",
            "tsTags": {
                "test1": signal_ID_split[0],
                "test2": signal_ID_split[1]
                }   
            
            }
        ]
    }
    print(signal_json)




    # signal_register = register_signal(host = API_ENDPOINT, proxies=PROXIES, site_name=SITE_NAME, device_id=DEVICE_ID, token=TOKEN, in_json = signal_json)

    # print(signal_register.text)

# signal_modify = modify_signal(host = API_ENDPOINT, proxies=PROXIES, site_name=SITE_NAME, device_id=DEVICE_ID, signals_id="CV_POS", token=TOKEN, in_json=modify_signal_json)

# print(signal_modify.text)         


