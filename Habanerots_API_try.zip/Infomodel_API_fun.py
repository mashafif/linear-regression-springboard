###Information_model-API関数一式###
#必要モジュールのインポート
import os
import json
import requests


###############Person API###############
#APIリスト取得API関数
def get_person_api_list(host, proxies, token):
    url = '%s/person/api/apis' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#組織ユーザ紐づけ登録API関数
def link_user_organization(host, proxies, organization_id, user_ids, token):
    url = '%s/person/api/organizations/%s/linkage' % (host, organization_id)
    data_dict = {'user_ids': user_ids}
    data = json.dumps(data_dict)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#組織ユーザ紐づけ解除API関数
def unlink_user_organization(host, proxies, organization_id, user_id, token):
    url = '%s/person/api/organizations/%s/persons/%s/linkage' % (host, organization_id, user_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#組織ユーザリスト取得API関数
def get_user_list(host, proxies, organization_id, params, token):
    url = '%s/person/api/organizations/%s/persons' % (host, organization_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#組織ユーザ登録API関数
def create_user(host, proxies, organization_id, create_user_requestbody, token):
    url = '%s/person/api/organizations/%s/persons' % (host, organization_id)
    data = json.dumps(create_user_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#組織ユーザ取得API関数
def get_user_info(host, proxies, organization_id, user_id, token):
    url = '%s/person/api/organizations/%s/persons/%s' % (host, organization_id, user_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#組織ユーザ更新API関数
def update_user_info(host, proxies, organization_id, user_id, update_user_requestbody, token):
    url = '%s/person/api/organizations/%s/persons/%s' % (host, organization_id, user_id)
    data = json.dumps(update_user_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#組織ユーザ削除API関数
def delete_user(host, proxies, organization_id, user_id, token):
    url = '%s/person/api/organizations/%s/persons/%s' % (host, organization_id, user_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#ユーザ取得(自分自身)API関数
def get_selfuser_info(host, proxies, token):
    url = '%s/person/api/persons/self' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res


###############Organization API###############
#組織リスト取得API関数
def get_organization_list(host, proxies, params, token):
    url = '%s/person/api/organizations' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#組織登録API関数
def create_organization(host, proxies, create_or_requestbody, token):
    url = '%s/person/api/organizations' % (host)
    data = json.dumps(create_or_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#組織取得API関数
def get_organization_info(host, proxies, organization_id, token):
    url = '%s/person/api/organizations/%s' % (host, organization_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#組織更新API関数
def update_organization_info(host, proxies, organization_id, update_or_requestbody, token):
    url = '%s/person/api/organizations/%s' % (host, organization_id)
    data = json.dumps(update_or_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#組織削除API関数
def delete_organization(host, proxies, organization_id, token):
    url = '%s/person/api/organizations/%s' % (host, organization_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res


###############Role API###############
#ロールリスト取得(組織跨り)API関数
def get_role_list_across(host, proxies, params, token):
    url = '%s/person/api/roles' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#ロールリスト取得API関数
def get_role_list(host, proxies, organization_id, params, token):
    url = '%s/person/api/organizations/%s/roles' % (host, organization_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#ロール登録API関数
def create_role(host, proxies, organization_id, create_role_requestbody, token):
    url = '%s/person/api/organizations/%s/roles' % (host, organization_id)
    data = json.dumps(create_role_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#ロール取得API関数
def get_role_info(host, proxies, organization_id, role_id, token):
    url = '%s/person/api/organizations/%s/roles/%s' % (host, organization_id, role_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#ロール更新API関数
def update_role_info(host, proxies, organization_id, role_id, update_role_requestbody, token):
    url = '%s/person/api/organizations/%s/roles/%s' % (host, organization_id, role_id)
    data = json.dumps(update_role_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#ロール削除API関数
def delete_role(host, proxies, organization_id, role_id, token):
    url = '%s/person/api/organizations/%s/roles/%s' % (host, organization_id, role_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#ロールユーザリスト取得API関数
def get_role_user_list(host, proxies, organization_id, role_id, params, token):
    url = '%s/person/api/organizations/%s/roles/%s/users' % (host, organization_id, role_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#ロールアカウント紐づけ登録API関数
def link_user_role(host, proxies, organization_id, role_id, acount_ids, token):
    url = '%s/person/api/organizations/%s/roles/%s/subjects' % (host, organization_id, role_id)
    data_dict = {'rlSubjects': acount_ids}
    data = json.dumps(data_dict)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#ロールアカウント紐づけ解除API関数
def unlink_user_role(host, proxies, organization_id, role_id, acount_ids, token):
    url = '%s/person/api/organizations/%s/roles/%s/subjects' % (host, organization_id, role_id)
    data_dict = {'rlSubjects': acount_ids}
    data = json.dumps(data_dict)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#ロール権限紐づけ登録API関数
def link_permission_role(host, proxies, organization_id, role_id, permission_ids, token):
    url = '%s/person/api/organizations/%s/roles/%s/permissions' % (host, organization_id, role_id)
    data_dict = {'rlRoleIds': permission_ids}
    data = json.dumps(data_dict)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#ロール権限紐づけ解除API関数
def unlink_permission_role(host, proxies, organization_id, role_id, permission_ids, token):
    url = '%s/person/api/organizations/%s/roles/%s/permissions' % (host, organization_id, role_id)
    data_dict = {'rlRoleIds': permission_ids}
    data = json.dumps(data_dict)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

###############Permission API###############
#権限リスト取得(組織跨り)API関数
def get_permission_list_across(host, proxies, params, token):
    url = '%s/person/api/permissions' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#権限リスト取得API関数
def get_permission_list(host, proxies, organization_id, params, token):
    url = '%s/person/api/organizations/%s/permissions' % (host, organization_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#権限登録API関数
def create_permission(host, proxies, organization_id, create_permission_requestbody, token):
    url = '%s/person/api/organizations/%s/permissions' % (host, organization_id)
    data = json.dumps(create_permission_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#権限取得API関数
def get_permission_info(host, proxies, organization_id, permission_id, token):
    url = '%s/person/api/organizations/%s/permissions/%s' % (host, organization_id, permission_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#権限更新API関数
def update_permission_info(host, proxies, organization_id, permission_id, update_permission_requestbody, token):
    url = '%s/person/api/organizations/%s/permissions/%s' % (host, organization_id, permission_id)
    data = json.dumps(update_permission_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#権限削除API関数
def delete_permission(host, proxies, organization_id, permission_id, token):
    url = '%s/person/api/organizations/%s/permissions/%s' % (host, organization_id, permission_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#アクションリスト取得(組織跨り)API関数
def get_action_list_across(host, proxies, params, token):
    url = '%s/person/api/actions' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#アクションリスト取得API関数
def get_action_list(host, proxies, organization_id, params, token):
    url = '%s/person/api/organizations/%s/actions' % (host, organization_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res











###############Site API###############
#APIリスト取得API関数
def get_site_api_list(host, proxies, token):
    url = '%s/site/api/apis' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#サイトリスト取得API関数
def get_site_list(host, proxies, params, token):
    url = '%s/site/api/sites' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#サイト登録API関数
def create_site(host, proxies, create_site_requestbody, token):
    url = '%s/site/api/sites' % (host)
    data = json.dumps(create_site_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#サイト取得API関数
def get_site_info(host, proxies, site_code, token):
    url = '%s/site/api/sites/%s' % (host, site_code)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#サイト更新API関数
def update_site_info(host, proxies, site_code, update_site_requestbody, token):
    url = '%s/site/api/sites/%s' % (host, site_code)
    data = json.dumps(update_site_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#サイト削除API関数
def delete_site(host, proxies, site_code, token):
    url = '%s/site/api/sites/%s' % (host, site_code)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res


###############Asset API###############
#APIリスト取得API関数
def get_asset_api_list(host, proxies, token):
    url = '%s/asset/api/apis' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#クラスプロパティリスト取得API関数
def get_class_property_list(host, proxies, class_code, params, token):
    url = '%s/asset/api/classes/%s/properties' % (host, class_code)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#設備リスト取得(全サイト跨り)API関数
def get_asset_list_across(host, proxies, params, token):
    url = '%s/asset/api/assets' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#設備リスト取得API関数
def get_asset_list(host, proxies, site_code, params, token):
    url = '%s/asset/api/sites/%s/assets' % (host, site_code)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#設備登録API関数
def create_asset(host, proxies, site_code, create_asset_requestbody, token):
    url = '%s/asset/api/sites/%s/assets' % (host, site_code)
    data = json.dumps(create_asset_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#設備取得API関数
def get_asset_info(host, proxies, site_code, equipment_id, token):
    url = '%s/asset/api/sites/%s/assets/%s' % (host, site_code, equipment_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#設備更新API関数
def update_asset_info(host, proxies, site_code, equipment_id, update_asset_requestbody, token):
    url = '%s/asset/api/sites/%s/assets/%s' % (host, site_code, equipment_id)
    data = json.dumps(update_asset_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#設備削除API関数
def delete_asset(host, proxies, site_code, equipment_id, token):
    url = '%s/asset/api/sites/%s/assets/%s' % (host, site_code, equipment_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#系統リスト取得(全サイト跨り)API関数
def get_system_list_across(host, proxies, params, token):
    url = '%s/asset/api/systems' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#系統リスト取得API関数
def get_system_list(host, proxies, site_code, params, token):
    url = '%s/asset/api/sites/%s/systems' % (host, site_code)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#系統登録API関数
def create_system(host, proxies, site_code, create_system_requestbody, token):
    url = '%s/asset/api/sites/%s/systems' % (host, site_code)
    data = json.dumps(create_system_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#系統取得API関数
def get_system_info(host, proxies, site_code, system_id, token):
    url = '%s/asset/api/sites/%s/systems/%s' % (host, site_code, system_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#系統更新API関数
def update_system_info(host, proxies, site_code, system_id, update_system_requestbody, token):
    url = '%s/asset/api/sites/%s/systems/%s' % (host, site_code, system_id)
    data = json.dumps(update_system_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#系統削除API関数
def delete_system(host, proxies, site_code, system_id, token):
    url = '%s/asset/api/sites/%s/systems/%s' % (host, site_code, system_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

###############RDS API###############
#RDSオブジェクトリスト取得(全サイト跨り)API関数
def get_rds_list_across(host, proxies, params, token):
    url = '%s/asset/api/rdss' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#RDSオブジェクトリスト取得API関数
def get_rds_list(host, proxies, site_code, params, token):
    url = '%s/asset/api/sites/%s/rdss' % (host, site_code)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#RDS登録API関数
def create_rds(host, proxies, site_code, create_rds_requestbody, token):
    url = '%s/asset/api/sites/%s/rdss' % (host, site_code)
    data = json.dumps(create_rds_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#RDS取得API関数
def get_rds_info(host, proxies, site_code, rds, token):
    url = '%s/asset/api/sites/%s/rdss/%s' % (host, site_code, rds)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#RDS更新API関数
def update_rds_info(host, proxies, site_code, rds, update_rds_requestbody, token):
    url = '%s/asset/api/sites/%s/rdss/%s' % (host, site_code, rds)
    data = json.dumps(update_rds_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#RDS削除API関数
def delete_rds(host, proxies, site_code, rds, token):
    url = '%s/asset/api/sites/%s/rdss/%s' % (host, site_code, rds)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#設備/系統リスト取得(RDS指定)(全サイト跨り)API関数
def get_asset_system_list_across_by_rds(host, proxies, params, token):
    url = '%s/asset/api/rdss/objects' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#設備/系統リスト取得(RDS指定)API関数
def get_asset_system_list_by_rds(host, proxies, site_code, params, token):
    url = '%s/asset/api/sites/%s/rdss/objects' % (host, site_code)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#設備/系統取得(RDS指定)API関数
def get_asset_system_by_rds(host, proxies, site_code, rds, params, token):
    url = '%s/asset/api/sites/%s/rdss/%s/objects' % (host, site_code, rds)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#設備/系統更新(RDS指定)API関数
def update_asset_system_by_rds(host, proxies, site_code, rds, update_asset_system_requestbody, token):
    url = '%s/asset/api/sites/%s/rdss/%s/objects' % (host, site_code, rds)
    data = json.dumps(update_asset_system_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res


###############Spare API###############
#予備品リスト取得(全サイト跨り)API関数
def get_spare_list_across(host, proxies, token):
    url = '%s/asset/api/spares' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#予備品リスト取得API関数
def get_spare_list(host, proxies, site_code, params, token):
    url = '%s/asset/api/sites/%s/spares' % (host, site_code)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#予備品登録API関数
def create_spare(host, proxies, site_code, create_spare_requestbody, token):
    url = '%s/asset/api/sites/%s/spares' % (host, site_code)
    data = json.dumps(create_spare_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#予備品取得API関数
def get_spare_info(host, proxies, site_code, spare_id, token):
    url = '%s/asset/api/sites/%s/spares/%s' % (host, site_code, spare_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#予備品更新API関数
def update_spare_info(host, proxies, site_code, spare_id, update_spare_requestbody, token):
    url = '%s/asset/api/sites/%s/spares/%s' % (host, site_code, spare_id)
    data = json.dumps(update_spare_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#予備品削除API関数
def delete_spare(host, proxies, site_code, spare_id, token):
    url = '%s/asset/api/sites/%s/spares/%s' % (host, site_code, spare_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res


###############Event API###############
#APIリスト取得API関数
def get_event_api_list(host, proxies, token):
    url = '%s/event/api/apis' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#イベントリスト取得(全サイト跨り)API関数
def get_event_list_across(host, proxies, params, token):
    url = '%s/event/api/events' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#イベントリスト取得API関数
def get_event_list(host, proxies, site_code, params, token):
    url = '%s/event/api/sites/%s/events' % (host, site_code)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#イベント登録API関数
def create_event(host, proxies, site_code, create_event_requestbody, token):
    url = '%s/event/api/sites/%s/events' % (host, site_code)
    data = json.dumps(create_event_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#イベント取得API関数
def get_event_info(host, proxies, site_code, event_id, params, token):
    url = '%s/event/api/sites/%s/events/%s' % (host, site_code, event_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(res.headers)
    print(json.dumps(res.json(), indent = 4))
    return res

#イベント更新API関数
def update_event_info(host, proxies, site_code, event_id, update_event_requestbody, token):
    url = '%s/event/api/sites/%s/events/%s' % (host, site_code, event_id)
    data = json.dumps(update_event_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(res.headers)
#    print(res.text)
#    print(json.dumps(res.json(), indent = 4))
    return res

#イベント削除API関数
def delete_event(host, proxies, site_code, event_id, token):
    url = '%s/event/api/sites/%s/events/%s' % (host, site_code, event_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#イベント添付ファイルリスト取得API関数
def get_event_file_list(host, proxies, site_code, event_id, token):
    url = '%s/event/api/sites/%s/events/%s/files' % (host, site_code, event_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#イベント添付ファイル登録API関数
def create_event_file(host, proxies, site_code, event_id, create_event_file_requestbody, token):
    url = '%s/event/api/sites/%s/events/%s/files' % (host, site_code, event_id)
    data = json.dumps(create_event_file_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#イベント添付ファイル取得API関数
def get_event_file(host, proxies, site_code, event_id, file_id, token):
    url = '%s/event/api/sites/%s/events/%s/files/%s' % (host, site_code, event_id, file_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#イベント添付ファイル削除API関数
def delete_event_file(host, proxies, site_code, event_id, file_id, token):
    url = '%s/event/api/sites/%s/events/%s/files/%s' % (host, site_code, event_id, file_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

###############Historian API###############
#APIリスト取得API関数
def get_historian_api_list(host, proxies, token):
    url = '%s/historian/api/apis' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#クラスプロパティリスト取得API関数
def get_historian_class_property_list(host, proxies, class_code, params, token):
    url = '%s/historian/api/classes/%s/properties' % (host, class_code)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#デバイス一覧取得(全サイト跨り)API関数
def get_device_list_across(host, proxies, params, token):
    url = '%s/historian/api/devices' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#デバイス一覧取得API関数
def get_device_list(host, proxies, site_code, params, token):
    url = '%s/historian/api/sites/%s/devices' % (host, site_code)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#デバイス登録API関数
def create_device(host, proxies, site_code, create_device_requestbody, token):
    url = '%s/historian/api/sites/%s/devices' % (host, site_code)
    data = json.dumps(create_device_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#デバイス取得API関数
def get_device_info(host, proxies, site_code, device_id, token):
    url = '%s/historian/api/sites/%s/devices/%s' % (host, site_code, device_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#デバイス更新API関数
def update_device_info(host, proxies, site_code, device_id, update_device_requestbody, token):
    url = '%s/historian/api/sites/%s/devices/%s' % (host, site_code, device_id)
    data = json.dumps(update_device_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#デバイス削除API関数
def delete_device(host, proxies, site_code, device_id, token):
    url = '%s/historian/api/sites/%s/devices/%s' % (host, site_code, device_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#デバイスシークレット再発行API関数
def reissue_device_secret(host, proxies, site_code, device_id, token):
    url = '%s/historian/api/sites/%s/devices/%s/secret' % (host, site_code, device_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.post(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#デバイスシークレット無効化API関数
def delete_device_secret(host, proxies, site_code, device_id, token):
    url = '%s/historian/api/sites/%s/devices/%s/secret' % (host, site_code, device_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#シグナル一覧取得(デバイス跨り)API関数
def get_signal_list_across(host, proxies, site_code, params, token):
    url = '%s/historian/api/sites/%s/signals' % (host, site_code)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#シグナル一覧取得API関数
def get_signal_list(host, proxies, site_code, device_id, params, token):
    url = '%s/historian/api/sites/%s/devices/%s/signals' % (host, site_code, device_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#シグナル登録API関数
def create_signal(host, proxies, site_code, device_id, create_signal_requestbody, token):
    url = '%s/historian/api/sites/%s/devices/%s/signals' % (host, site_code, device_id)
    data = json.dumps(create_signal_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#シグナル取得API関数
def get_signal_info(host, proxies, site_code, device_id, signal_id, token):
    url = '%s/historian/api/sites/%s/devices/%s/signals/%s' % (host, site_code, device_id, signal_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#シグナル更新API関数
def update_signal_info(host, proxies, site_code, device_id, signal_id, update_signal_requestbody, token):
    url = '%s/historian/api/sites/%s/devices/%s/signals/%s' % (host, site_code, device_id, signal_id)
    data = json.dumps(update_signal_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#シグナル削除API関数
def delete_signal(host, proxies, site_code, device_id, signal_id, token):
    url = '%s/historian/api/sites/%s/devices/%s/signals/%s' % (host, site_code, device_id, signal_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#時系列データ登録API関数[JSON]
def create_timeseries_data_json(host, proxies, site_code, device_id, device_secret, create_timeseries_requestbody, token, auth_type):
    url = '%s/historian/api/exp/sites/%s/devices/%s/signals/timeseries' % (host, site_code, device_id)
    data = json.dumps(create_timeseries_requestbody)
    if auth_type == 'DeviceAuthBasic':
        headers = {'Content-Type': 'application/json'}
        auth = (device_id, device_secret)
    else:
        headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
        auth = (None, None)
    res = requests.post(url, data = data, headers = headers, auth = auth, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#時系列データ登録API関数用JSONリクエストボディ作成関数
def make_timeseries_requestbody(timestamp_list, iid, v_list, q_list):
    res = {
        'timeseries': [
            {
                'time': timestamp,
                'iid': iid,
                'v': v,
                'q': q
            }
            for timestamp, v, q in zip(timestamp_list, v_list, q_list)
        ]
    }
    return res

#時系列データ登録API関数[CSV]
def create_timeseries_data_csv(host, proxies, site_code, device_id, device_secret, csv_filepath, token, auth_type):
    url = '%s/historian/api/exp/sites/%s/devices/%s/signals/timeseries' % (host, site_code, device_id)
    with open(csv_filepath, 'rb') as f:
        file_content = f.read()
    filename = os.path.basename(csv_filepath)
    files = {'file': (filename, file_content, 'application/octet-stream')}
    if auth_type == 'DeviceAuthBasic':
#        headers = {'Content-Type': 'application/json'}
#        headers = {'Content-Type': 'multipart/form-data'}
        headers = {'Content-Type': ''}
        auth = (device_id, device_secret)
    else:
        headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
        auth = (None, None)
#    res = requests.post(url, files = files, headers = headers, auth = auth, proxies = proxies, verify = False)
    res = requests.post(url, files = files, auth = auth, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#時系列データ取得API関数
def get_timeseries_data(host, proxies, site_code, device_id, get_timeseries_requestbody, token):
    url = '%s/historian/api/exp/sites/%s/devices/%s/signals/timeseries/query' % (host, site_code, device_id)
    data = json.dumps(get_timeseries_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#最新時系列データ取得API関数
def get_timeseries_data_latest(host, proxies, site_code, device_id, get_timeseries_latest_requestbody, token):
    url = '%s/historian/api/exp/sites/%s/devices/%s/signals/timeseries/latest' % (host, site_code, device_id)
    data = json.dumps(get_timeseries_latest_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#RDSプロパティ時系列データ登録API関数[JSON]
def create_timeseries_data_json_by_rds(host, proxies, site_code, rds, property_code, create_timeseries_requestbody, token):
    url = '%s/historian/api/sites/%s/rdss/%s/properties/%s/data' % (host, site_code, rds, property_code)
    data = json.dumps(create_timeseries_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#RDSプロパティ時系列データ登録API関数用JSONリクエストボディ作成関数
def make_timeseries_requestbody_by_rds(timestamp_list, v_list, q_list):
    res = {
        'timeseries': [
            {
                'time': timestamp,
                'v': v,
                'q': q
            }
            for timestamp, v, q in zip(timestamp_list, v_list, q_list)
        ]
    }
    return res

#RDSプロパティ時系列データ取得API関数
def get_timeseries_data_by_rds(host, proxies, site_code, rds, get_timeseries_requestbody, token):
    url = '%s/historian/api/sites/%s/rdss/%s/data/historian' % (host, site_code, rds)
    data = json.dumps(get_timeseries_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#RDSプロパティ最新時系列データ取得API関数
def get_timeseries_data_latest_by_rds(host, proxies, site_code, rds, get_timeseries_latest_requestbody, token):
    url = '%s/historian/api/sites/%s/rdss/%s/data/latest' % (host, site_code, rds)
    data = json.dumps(get_timeseries_latest_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res








###############Media API###############
#デバイスファイル登録API関数(デバイスBasic認証)
def create_devicefile_basic(host, proxies, site_code, device_id, device_secret, filepath, devicefile_tags, token):
    url = '%s/media/api/sites/%s/devices/%s/media' % (host, site_code, device_id)
    with open(filepath, 'rb') as f:
        file_content = f.read()
    filename = os.path.basename(filepath)
#    files = {'file': (filename, file_content, 'application/octet-stream')}
    files = {'file': (filename, file_content, 'application/octet-stream'), 'flFileTags': ('', json.dumps(devicefile_tags), 'application/json')}
    data = json.dumps({
        'tags': {'test': '001'}
    })
#    headers = {'Content-Type': 'multipart/form-data', 'Authorization': 'Bearer %s' % token}
    headers = {'Authorization': 'Bearer %s' % token}
    auth = (device_id, device_secret)
#    res = requests.post(url, headers = headers, files = files, auth = auth, proxies = proxies, verify = False)
    res = requests.post(url, files = files, auth = auth, proxies = proxies, verify = False)
#    res = requests.post(url, files = files, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#デバイスファイル登録API関数
def create_devicefile(host, proxies, site_code, device_id, filepath, token):
    url = '%s/media/api/sites/%s/devices/%s/media' % (host, site_code, device_id)
    with open(filepath, 'rb') as f:
        file_content = f.read()
    filename = os.path.basename(filepath)
    files = {'file': (filename, file_content, 'application/octet-stream')}
    data = json.dumps({
        'tags': {'test': '001'}
    })
#    headers = {'Content-Type': 'multipart/form-data', 'Authorization': 'Bearer %s' % token}
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.post(url, files = files, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#デバイスファイル取得API関数
def get_devicefile(host, proxies, site_code, device_id, file_id, params, token):
    url = '%s/media/api/sites/%s/devices/%s/media/%s' % (host, site_code, device_id, file_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#デバイスファイル更新API関数
def update_devicefile(host, proxies, site_code, device_id, file_id, filepath, devicefile_tags, token):
    url = '%s/media/api/sites/%s/devices/%s/media/%s' % (host, site_code, device_id, file_id)
    with open(filepath, 'rb') as f:
        file_content = f.read()
    filename = os.path.basename(filepath)
    files = {'file': (filename, file_content, 'application/octet-stream'), 'flFileTags': ('', json.dumps(devicefile_tags), 'application/json')}
    data = json.dumps({
#        'name': 'zzzzzzzz.png'
        'tags': {'siteCode': 'toshiba-fuchu-factory'}
    })
#    headers = {'Content-Type': 'multipart/form-data', 'Authorization': 'Bearer %s' % token}
    headers = {'Authorization': 'Bearer %s' % token}
#    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, files = files, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#デバイスファイル削除API関数
def delete_devicefile(host, proxies, site_code, device_id, file_id, token):
    url = '%s/media/api/sites/%s/devices/%s/media/%s' % (host, site_code, device_id, file_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res














###############Diagram API###############
#サイト図面更新API関数
def update_diagram_info(host, proxies, site_code, file_id, update_diagram_requestbody, token):
    url = '%s/diagram/api/sites/%s/diagrams/%s' % (host, site_code, file_id)
    data = json.dumps(update_diagram_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(res.headers)
#    print(res.text)
#    print(json.dumps(res.json(), indent = 4))
    return res


###############Concern API###############
#APIリスト取得API関数
def get_concern_api_list(host, proxies, token):
    url = '%s/concern/api/apis' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#クラスプロパティリスト取得API関数
def get_concern_class_property_list(host, proxies, class_code, params, token):
    url = '%s/concern/api/classes/%s/properties' % (host, class_code)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#コンサーン一覧取得API関数
def get_concern_list(host, proxies, params, token):
    url = '%s/concern/api/concerns' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#コンサーン登録API関数
def create_concern(host, proxies, create_concern_requestbody, token):
    url = '%s/concern/api/concerns' % (host)
    data = json.dumps(create_concern_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#コンサーン取得API関数
def get_concern_info(host, proxies, concern_id, params, token):
    url = '%s/concern/api/concerns/%s' % (host, concern_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#コンサーン更新API関数
def update_concern_info(host, proxies, concern_id, update_concern_requestbody, token):
    url = '%s/concern/api/concerns/%s' % (host, concern_id)
    data = json.dumps(update_concern_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#コンサーン削除API関数
def delete_concern(host, proxies, concern_id, token):
    url = '%s/concern/api/concerns/%s' % (host, concern_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res


###############Client API###############
#APIリスト取得API関数
def get_client_api_list(host, proxies, token):
    url = '%s/client/api/apis' % (host)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#クラスプロパティリスト取得API関数
def get_client_class_property_list(host, proxies, class_code, params, token):
    url = '%s/client/api/classes/%s/properties' % (host, class_code)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#クライアントリスト取得(組織跨り)API関数
def get_client_list_across(host, proxies, params, token):
    url = '%s/client/api/clients' % (host)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#クライアントリスト取得API関数
def get_client_list(host, proxies, organization_id, params, token):
    url = '%s/client/api/organizations/%s/clients' % (host, organization_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#クライアント登録API関数
def create_client(host, proxies, organization_id, create_client_requestbody, token):
    url = '%s/client/api/organizations/%s/clients' % (host, organization_id)
    data = json.dumps(create_client_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#クライアント取得API関数
def get_client_info(host, proxies, organization_id, client_id, params, token):
    url = '%s/client/api/organizations/%s/clients/%s' % (host, organization_id, client_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#クライアント更新API関数
def update_client_info(host, proxies, organization_id, client_id, update_client_requestbody, token):
    url = '%s/client/api/organizations/%s/clients/%s' % (host, organization_id, client_id)
    data = json.dumps(update_client_requestbody)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#クライアント削除API関数
def delete_client(host, proxies, organization_id, client_id, token):
    url = '%s/client/api/organizations/%s/clients/%s' % (host, organization_id, client_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#クライアントシークレット更新API関数
def refresh_client_secret(host, proxies, organization_id, client_id, token):
    url = '%s/client/api/organizations/%s/clients/%s/secret' % (host, organization_id, client_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.post(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#クライアントトークン簡易発行API関数
def get_client_token(host, proxies, organization_id, client_id, token):
    url = '%s/client/api/organizations/%s/clients/%s/token' % (host, organization_id, client_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res











###############Model API###############
#APIリスト取得API関数
def get_model_api_list(host, proxies, token):
    url = '%s/model/api/apis' % (host)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#クラスリスト取得API関数
def get_class_list(host, proxies, token):
    url = '%s/model/api/classes' % (host)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#クラス情報取得API関数
def get_class_info(host, proxies, class_code, params, token):
    url = '%s/model/api/classes/%s/properties' % (host, class_code)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#指定クラス・プロパティを使用するサービスリスト取得API関数
def get_class_property_service_list(host, proxies, class_code, property_code, token):
    url = '%s/model/api/classes/%s/properties/%s/services' % (host, class_code, property_code)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#情報モデルを参照しているサービスリスト取得API関数
def get_model_service_list(host, proxies, token):
    url = '%s/model/api/services' % (host)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res





