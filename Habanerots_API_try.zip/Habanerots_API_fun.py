###Habanerots-API関数一式###
#必要モジュールのインポート
import os
import json
import requests
import numpy as np


#時系列データ登録API関数(JSON形式)
def write_data_json(host, proxies, device_id, device_secret, timeseries):
    url = '%s/exp/devices/%s/signals/timeseries' % (host, device_id)
    data = json.dumps({
        'timeseries': timeseries
    })
    headers = {'Content-Type': 'application/json'}
    auth = (device_id, device_secret)
    res = requests.post(url, data = data, headers = headers, auth = auth, proxies = proxies, verify = False)
    print(url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#時系列データ登録API関数(JSON形式)用リクエストボディtimeseries作成関数
def request_body_timeseries(time_list, iid, v_list, q_list):
    timeseries = [{'time': timestamp, 'iid': iid, 'v': v, 'q': q} for timestamp, v, q in zip(time_list, v_list, q_list)]
    return timeseries

#時系列データ登録API関数(CSV形式)
def write_data_csv(host, proxies, device_id, device_secret, csv_file):
    url = '%s/exp/devices/%s/signals/timeseries' % (host, device_id)
    csv_file = csv_file
    binary = open(csv_file, 'rb').read()
    files = {'file': (csv_file, binary, 'application/octet-stream')}
    auth = (device_id, device_secret)
    res = requests.post(url, files = files, auth = auth, proxies = proxies, verify = False)
    print(url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#時系列データ取得API関数(start-end時間区間指定)
def read_data_general(host, proxies, device_id, token, iids, start, end, interval, func, timezone):
    url = '%s/exp/devices/%s/signals/timeseries/query' % (host, device_id)
    data_dict = {
        'iids': iids,
        'start': start,
        'end': end,
        'interval': interval,
        'func': func,
        'timezone': timezone
    }
    if len(interval) == 0:
        del data_dict['func']
    
    data = json.dumps(data_dict)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(url)
    print(res.status_code)
    #print(json.dumps(res.json(), indent = 4))
    return res

#最新時系列データ取得API関数
def read_data_latest(host, proxies, device_id, token, iids, time_latest):
    url = '%s/exp/devices/%s/signals/timeseries/query/latest' % (host, device_id)
    data = json.dumps({
        'iids': iids,
        'time': time_latest
    })
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#iid登録API関数
def add_iid(host, proxies, device_id, token, iids, data_types):
    url = '%s/devices/%s/signals' % (host, device_id)
    signals = [{'label': iid, 'type': data_type} for iid, data_type in zip(iids, data_types)]
    data_dict = {'signals': signals}
    data = json.dumps(data_dict)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#iid削除API関数
def delete_iid(host, proxies, device_id, token, iid):
    url = '%s/devices/%s/signals/%s' % (host, device_id, iid)
    data = json.dumps({
    })
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(url)
    print(res.status_code)
    #print(json.dumps(res.json(), indent = 4))
    return res

######Device API######
#デバイス登録API関数
def create_device(host, proxies, device_name, device_description, token):
    url = '%s/devices' % (host)
    data_dict = {'name': device_name, 'description': device_description}
    data = json.dumps(data_dict)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.post(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#デバイスリスト取得API関数
def get_device_list(host, proxies, parent_device_id, token):
    url = '%s/devices?parent_device_id=%s' % (host, parent_device_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#デバイス取得API関数
def get_device_info(host, proxies, device_id, token):
    url = '%s/devices/%s' % (host, device_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#デバイス更新API関数
def update_device_info(host, proxies, device_id, device_name, device_description, device_tags, token):
    url = '%s/devices/%s' % (host, device_id)
    data_dict = {'name': device_name, 'description': device_description, 'tags': device_tags}
    data = json.dumps(data_dict)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#デバイス削除API関数
def delete_device(host, proxies, device_id, token):
    url = '%s/devices/%s' % (host, device_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res




######File API######
#デバイスファイル登録API関数
def write_devicefile(host, proxies, device_id, device_secret, filepath, devicefile_tags):
    url = '%s/devices/%s/files' % (host, device_id)
    with open(filepath, 'rb') as f:
        file_content = f.read()
    filename = os.path.basename(filepath)
    files = {'file': (filename, file_content, 'application/octet-stream'), 'tags': ('', json.dumps(devicefile_tags), 'application/json')}
    headers = {'Content-Type': 'application/json'}
    auth = (device_id, device_secret)
    res = requests.post(url, files = files, auth = auth, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#デバイスファイル取得API関数
def read_devicefile(host, proxies, device_id, token, file_id):
    url = '%s/devices/%s/files/%s' % (host, device_id, file_id)
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    #print(json.dumps(res.json(), indent = 4))
    return res

#デバイスファイル更新API関数
def update_devicefile(host, proxies, device_id, file_id, filepath, devicefile_tags, token):
    url = '%s/devices/%s/files/%s' % (host, device_id, file_id)
    if filepath:
        with open(filepath, 'rb') as f:
            file_content = f.read()
        filename = os.path.basename(filepath)
        files = {'file': (filename, file_content, 'application/octet-stream'), 'tags': ('', json.dumps(devicefile_tags), 'application/json')}
        headers = {'Authorization': 'Bearer %s' % token}
        res = requests.patch(url, files = files, headers = headers, proxies = proxies, verify = False)
    else:
        data_dict = {'tags': devicefile_tags}
        data = json.dumps(data_dict)
        headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
        res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#デバイスファイル削除API関数
def delete_devicefile(host, proxies, device_id, token, file_id):
    url = '%s/devices/%s/files/%s' % (host, device_id, file_id)
    data = json.dumps({
    })
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    #print(json.dumps(res.json(), indent = 4))
    return res

#デバイスファイル情報リスト取得API関数
def get_devicefile_list(host, proxies, device_id, params, token):
    url = '%s/devices/%s/files' % (host, device_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#アクセストークン発行API関数
def get_client_token(host_2, proxies, client_id, client_secret):
    url = '%s/v1/token' % (host_2)
    data = {'grant_type': 'client_credentials'}
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    auth = (client_id, client_secret)
    res = requests.post(url, data = data, headers = headers, auth = auth, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res.json()['access_token']

#クライアントファイル登録API関数
def write_clientfile(host, proxies, client_id, filepath, clientfile_tags, token):
    url = '%s/clients/%s/files' % (host, client_id)
    with open(filepath, 'rb') as f:
        file_content = f.read()
    filename = os.path.basename(filepath)
    files = {'file': (filename, file_content, 'application/octet-stream'), 'tags': ('', json.dumps(clientfile_tags), 'application/json')}
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.post(url, files = files, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#クライアントファイル取得API関数
def read_clientfile(host, proxies, client_id, file_id, token):
    url = '%s/clients/%s/files/%s' % (host, client_id, file_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    #print(json.dumps(res.json(), indent = 4))
    return res

#クライアントファイル更新API関数
def update_clientfile(host, proxies, client_id, file_id, filepath, clientfile_tags, token):
    url = '%s/clients/%s/files/%s' % (host, client_id, file_id)
    if filepath:
        with open(filepath, 'rb') as f:
            file_content = f.read()
        filename = os.path.basename(filepath)
        files = {'file': (filename, file_content, 'application/octet-stream'), 'tags': ('', json.dumps(clientfile_tags), 'application/json')}
        headers = {'Authorization': 'Bearer %s' % token}
        res = requests.patch(url, files = files, headers = headers, proxies = proxies, verify = False)
    else:
        data_dict = {'tags': clientfile_tags}
        data = json.dumps(data_dict)
        headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % token}
        res = requests.patch(url, data = data, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
#    print(json.dumps(res.json(), indent = 4))
    return res

#クライアントファイル削除API関数
def delete_clientfile(host, proxies, client_id, file_id, token):
    url = '%s/clients/%s/files/%s' % (host, client_id, file_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.delete(url, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    #print(json.dumps(res.json(), indent = 4))
    return res

#クライアントファイル情報リスト取得API関数
def get_clientfile_list(host, proxies, client_id, params, token):
    url = '%s/clients/%s/files' % (host, client_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.get(url, params = params, headers = headers, proxies = proxies, verify = False)
    print(res.url)
    print(res.status_code)
    print(json.dumps(res.json(), indent = 4))
    return res

#デバイスファイル名⇒ファイルID変換関数
def filename_to_fileid_conv(host, proxies, device_id, params, devicefile_name, token):
    res_file_info_list = get_devicefile_list(host, proxies, device_id, params, token)
    file_id_list = []
    file_name_list = []
    for file_info in res_file_info_list.json()['files']:
        file_id_list.append(file_info['id'])
        file_name_list.append(file_info['name'])
    
    file_id = ''
    for i in range(len(file_id_list)):
        if file_name_list[i] == devicefile_name:
            file_id = file_id_list[i]
            break

    return file_id

#ファイルID⇒デバイスファイル名変換関数
def fileid_to_filename_conv(host, proxies, device_id, params, devicefile_id, token):
    res_file_info_list = get_devicefile_list(host, proxies, device_id, params, token)
    file_id_list = []
    file_name_list = []
    for file_info in res_file_info_list.json()['files']:
        file_id_list.append(file_info['id'])
        file_name_list.append(file_info['name'])
    
    file_name = ''
    for i in range(len(file_id_list)):
        if file_id_list[i] == devicefile_id:
            file_name = file_name_list[i]
            break

    return file_name

#クライアントファイル名⇒ファイルID変換関数
def filename_to_fileid_conv_client(host, proxies, client_id, params, clientfile_name, token):
    res_file_info_list = get_clientfile_list(host, proxies, client_id, params, token)
    file_id_list = []
    file_name_list = []
    for file_info in res_file_info_list.json()['files']:
        file_id_list.append(file_info['id'])
        file_name_list.append(file_info['name'])
    
    file_id = ''
    for i in range(len(file_id_list)):
        if file_name_list[i] == clientfile_name:
            file_id = file_id_list[i]
            break

    return file_id

#ファイルID⇒クライアントファイル名変換関数
def fileid_to_filename_conv_client(host, proxies, client_id, params, clientfile_id, token):
    res_file_info_list = get_clientfile_list(host, proxies, client_id, params, token)
    file_id_list = []
    file_name_list = []
    for file_info in res_file_info_list.json()['files']:
        file_id_list.append(file_info['id'])
        file_name_list.append(file_info['name'])
    
    file_name = ''
    for i in range(len(file_id_list)):
        if file_id_list[i] == clientfile_id:
            file_name = file_name_list[i]
            break

    return file_name





