import requests



def register_signal(host, proxies, site_name, device_id,  token, in_json):
    url = '%s/sites/%s/devices/%s/signals' % (host, site_name, device_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.post(url, headers = headers, proxies = proxies, json = in_json, verify = False)
    print(res.url)
    print(res.status_code)
    #print(json.dumps(res.json(), indent = 4))
    return res


def modify_signal(host, proxies, site_name, device_id, token, in_json,signals_id,):
    url = '%s/sites/%s/devices/%s/signals/%s' % (host, site_name, device_id,signals_id)
    headers = {'Authorization': 'Bearer %s' % token}
    res = requests.patch(url, headers = headers, proxies = proxies, json = in_json, verify = False)
    print(res.url)
    print(res.status_code)
    #print(json.dumps(res.json(), indent = 4))
    return res
